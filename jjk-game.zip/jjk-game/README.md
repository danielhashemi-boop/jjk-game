# ✦ Jujutsu Kaisen Incremental

A multiplayer browser RPG inspired by JJK. Train, roll techniques and clans, fight cursed spirits, battle bosses, duel other players in real-time.

## Features
- 🎲 Gacha system — Clans + Techniques with SS+/SS/S/A/B/C/D rarities
- ⚔ Real-time PvP duels via WebSocket
- 👁 Boss fights — Toji Zenin & Ryomen Sukuna
- 🌐 Multiplayer rooms with world chat
- 📋 Daily missions & achievements
- 🌀 Prestige/Ascension system
- 💾 Save/load system
- 🏆 Leaderboard

## Deploy to Render (Free)

1. Push this repo to GitHub
2. Go to [render.com](https://render.com) and create a **New Web Service**
3. Connect your GitHub repo
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment:** Node
5. Click **Deploy** — done!

## Local Dev

```bash
npm install
npm start
# Open http://localhost:3000
```
